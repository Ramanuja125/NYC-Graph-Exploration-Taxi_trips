Steps to build and run the program
1) Building the docker
docker build -t img_name .
2) Running the docker
docker run -it img_name
3) The docker would open with the root and the working directory as /cse511/
root@d7ce31e37cbb:/cse511#
At this stage, we have loaded the data and installed the plugin
----------end of step 1 and step 2-----------
4) Start the neo4j
neo4j start
5) Execute the tester.py file.
python3 tester.py

This would produce the below output --- > 

root@d7ce31e37cbb:/cse511# python3 tester.py
Trying to connect to server
Server is running

----------------------------------
Testing if data is loaded into the database
        Count of Edges is correct: PASS
        Count of Edges is correct: PASS
Testing if PageRank is working
        PageRank Test 1: PASS
Testing if BFS is working
        BFS Test 2: PASS
----------------------------------

Testing Complete: Note that the test cases are not exhaustive. You should run your own tests to ensure that your code is working correctly.