from neo4j import GraphDatabase


class Interface:
    def __init__(self, uri, user, password):
        self._driver = GraphDatabase.driver(uri, auth=(user, password), encrypted=False)
        self._driver.verify_connectivity()

    def close(self):
        self._driver.close()

    def bfs(self, starting_node_name, destination_names):
        #TODO: Implement this method
		
		
        with self._driver.session() as session:
            try:
                if not isinstance(destination_names, list):
                    destination_names = [destination_names]

                drop_projection_query = """
                CALL gds.graph.exists('graph_bfs') YIELD exists
                WHERE exists
                CALL gds.graph.drop('graph_bfs', false) YIELD graphName
                RETURN graphName
                """
                session.run(drop_projection_query)

                query = """
                CALL gds.graph.project(
                    'graph_bfs',
                    'Location',  
                    {
                        TRIP: {  
                            orientation: 'UNDIRECTED',
                            properties: 'distance'  
                        }
                    }
                ) YIELD graphName
                RETURN graphName
                """
                session.run(query)

                start_node_id = session.run(
                    "MATCH (n:Location {name: $starting_node_name}) RETURN id(n) AS nodeId", 
                    starting_node_name=starting_node_name
                ).single()["nodeId"]

                destination_node_ids = [record["nodeId"] for record in session.run(
                    "MATCH (n:Location) WHERE n.name IN $destination_names RETURN id(n) AS nodeId", 
                    destination_names=destination_names
                )]

                bfs_query = """
                UNWIND $destination_node_ids AS destNode
                CALL gds.shortestPath.dijkstra.stream('graph_bfs', {
                    sourceNode: $start_node_id,
                    targetNode: destNode,
                    relationshipWeightProperty: 'distance'  
                })
                YIELD nodeIds, totalCost
                RETURN [node IN nodeIds | gds.util.asNode(node).name] AS path, totalCost
                """
                result = session.run(bfs_query, start_node_id=start_node_id, destination_node_ids=destination_node_ids)

                bfs_paths = []
                for record in result:
                    path_with_names = [{'name': node_name} for node_name in record["path"]]
                    bfs_paths.append({
                        "path": path_with_names,
                        "totalCost": record["totalCost"]
                    })

                return bfs_paths if bfs_paths else None
            except Exception as e:
                return []

    def pagerank(self, max_iterations=20, weight_attr='distance'):
        # TODO: Implement this method
		
		
        with self._driver.session() as session:
            try:
                # Drop the graph if it already exists
                drop_projection_query = """
                CALL gds.graph.exists('graph_pagerank') YIELD exists
                WHERE exists
                CALL gds.graph.drop('graph_pagerank', false) YIELD graphName
                RETURN graphName
                """
                session.run(drop_projection_query)

                query = f"""
                CALL gds.graph.project(
                    'graph_pagerank',
                    'Location',  
                    {{
                        TRIP: {{  
                            properties: ['{weight_attr}']
                        }}
                    }}
                )
                """
                session.run(query)

                list_graphs_query = "CALL gds.graph.list() YIELD graphName RETURN graphName"
                graph_names = session.run(list_graphs_query)
                projected_graph_list = [record["graphName"] for record in graph_names]

                run_pagerank_query = f"""
                CALL gds.pageRank.stream('graph_pagerank', {{
                    maxIterations: {max_iterations},
                    dampingFactor: 0.85,
                    relationshipWeightProperty: '{weight_attr}'
                }})
                YIELD nodeId, score
                WITH gds.util.asNode(nodeId).name AS name, score
                ORDER BY score DESC
                RETURN {{name: name, score: score}} AS result
                LIMIT 1

                UNION

                CALL gds.pageRank.stream('graph_pagerank', {{
                    maxIterations: {max_iterations},
                    dampingFactor: 0.85,
                    relationshipWeightProperty: '{weight_attr}'
                }})
                YIELD nodeId, score
                WITH gds.util.asNode(nodeId).name AS name, score
                ORDER BY score ASC
                RETURN {{name: name, score: score}} AS result
                LIMIT 1;
                """
                result = session.run(run_pagerank_query)

                nodes = [{"name": record["result"]["name"], "score": record["result"]["score"]} for record in result]

                for node in nodes:
                    node['score'] = round(node['score'], 5)

                
                return nodes
            except Exception as e:
                return []
