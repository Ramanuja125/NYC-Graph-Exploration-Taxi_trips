#tested and passes with all test cases.
from neo4j import GraphDatabase

class Interface:
    def __init__(self, uri, user, password):
        self._driver = GraphDatabase.driver(uri, auth=(user, password), encrypted=False)
        self._driver.verify_connectivity()

    def close(self):
        self._driver.close()

    def bfs(self, start_node, last_node):
        # TODO: Implement this method
        with self._driver.session() as session:
            try:
                if not isinstance(last_node, list):
                    last_node = [last_node]

                query = """MATCH path = shortestPath((start:Location)-[:TRIP*]-(dest:Location))
                WHERE start.name = $start_node AND dest.name IN $last_node
                RETURN [node IN nodes(path) | node.name] AS path, 
                       reduce(cost = 0, r IN relationships(path) | cost + r.distance) AS totalCost"""
                result = session.run(query, start_node=start_node, last_node=last_node)

                bfs_paths = []
                for record in result:
                    path_with_names = [{'name': node_name} for node_name in record["path"]]
                    bfs_paths.append({
                        "path": path_with_names,
                        "totalCost": record["totalCost"]
                    })

                return bfs_paths if bfs_paths else None
            except Exception as e:
                return []

    def pagerank(self, max_iterations=20, weight_attr='distance'):
        # TODO: Implement this method
        with self._driver.session() as session:
            try:
                drop_query = """CALL gds.graph.exists('graph_pagerank') YIELD exists
                WHERE exists
                CALL gds.graph.drop('graph_pagerank', false) YIELD graphName
                RETURN graphName"""
                session.run(drop_query)

                query_to_project = f"""CALL gds.graph.project(
                    'graph_pagerank',
                    'Location',
                    {{
                        TRIP: {{
                            properties: ['{weight_attr}']
                        }}
                    }}
                )"""
                session.run(query_to_project)

                pagerank_query = f"""CALL gds.pageRank.stream('graph_pagerank', {{
                    maxIterations: {max_iterations},
                    dampingFactor: 0.85,
                    relationshipWeightProperty: '{weight_attr}'
                }})
                YIELD nodeId, score
                RETURN nodeId, score"""
                pagerank_results = session.run(pagerank_query)

                node_results = session.run("MATCH (n:Location) RETURN n")
                node_map = {node["n"].id: node["n"]["name"] for node in node_results}

                nodes = []
                for record in pagerank_results:
                    node_name = node_map.get(record["nodeId"])
                    if node_name:
                        nodes.append({"name": node_name, "score": round(record["score"], 5)})

                
                nodes_sorted = sorted(nodes, key=lambda x: x["score"], reverse=True)
                top_result = nodes_sorted[0] if nodes_sorted else None
                bottom_result = nodes_sorted[-1] if nodes_sorted else None

                return [top_result, bottom_result] if top_result and bottom_result else []
            except Exception as e:
                return []
