This is a readme file to explain the process of running the files, 
The steps mentioned in the Grader.md can be followed, with a few changes which I will mark in this file.
Pre - requisites 
Before we start - please have the latest2 image pulled using - docker pull veedata/kafka-neo4j-connect:latest2
Have the parquet file - yellow_tripdata_2022-03.parquet in the same location as the files when it is being extracted.
Have the latest data_producer.py

Instructions after minikube and helm is installed - 
1) 
$$ - minikube start --memory=4096 --cpus=2  - <Change from the grader.md - memory and CPU>
2) 
$$ - kubectl apply -f ./zookeeper-setup.yaml
$$ - kubectl apply -f ./kafka-setup.yaml
This completes step 1
3) 

-----------Above step is optional if it is already installed ---------------------------------------------
Installation of neo4j repo and updating it, adding it here, just in case - 
$$ - helm repo add neo4j https://helm.neo4j.com/neo4j
$$ - helm repo update  

If it already exists -
$$ - helm upgrade my-neo4j-release neo4j/neo4j -f neo4j-values.yaml

-----------Above step is optional ---------------------------------------------

$$ - helm install my-neo4j-release neo4j/neo4j -f neo4j-values.yaml
$$ - kubectl apply -f neo4j-service.yaml

This completes step 2
4) 
$$ - kubectl apply -f kafka-neo4j-connector.yaml

This completes step 3
It will take some time to have all the pods up and running with ready status, please don't load the data until that is done.

5)
Before proceeding to the next step, please ensure that all the pods that get created are running and are in 1/1 state - example - 
$$ - kubectl get pods
NAME                                     READY   STATUS    RESTARTS   AGE
kafka-deployment-c7cc98495-q7hh2         1/1     Running   0          14h
kafka-neo4j-connector-7b47d88ccd-7n526   1/1     Running   0          14h
my-neo4j-release-0                       1/1     Running   0          14h
zookeeper-deployment-7449b76cb5-b86jp    1/1     Running   0          14h

In a separate terminal, forward 4 ports - 
$$ - kubectl port-forward svc/neo4j-service 7474:7474 7687:7687
$$ - kubectl port-forward svc/kafka-service 9092:9092 29092:29092

Once these we can load the data using the latest data_producer.py file
$$ - python3 data_producer.py

Once all the data is loaded, we can test the tester.py.
$$ - python3 tester.py

Please use the interface.py that is attached in the zip file, as I have made changes to it as compared to the interface.py file used in Project 1 Phase 1.
With the above tests, we should be getting the below outputs.

------------------------ additional information to help troubleshoot if the data is not loaded to neo4j.
The reason for the data to be not loaded even after running the data_producer.py and not see any data in the neo4j browser is the kafka deplopyment is not scaled up, with the below command we can scale up the kafka deployment.

kubectl scale deployment kafka-neo4j-connector --replicas=1

Once this is done, log in to the kafka-deplyment- pod with the command - <Example for the above kubectl get pods>
$$ - kubectl exec -it kafka-deployment-c7cc98495-q7hh2 -- bash
And the the below commands
$$ - kafka-topics --bootstrap-server localhost:9092 --delete --topic nyc_taxicab_data

$$ - kafka-topics --bootstrap-server localhost:9092 --create --topic nyc_taxicab_data --partitions 1 --replication-factor 1
Recrates the topic.

If there are any stale nodes, remove the nodes in neo4j as well.
MATCH (n) DETACH DELETE n;

The above cypher-shell command will delete if any nodes or relations are present in the neo4j.

---------------------------------------------------------------------------------------------------------------------------------
- Sample Outputs - 
C:\Users\anant\Downloads\ASU\Course work\CSE Data processing at scale\Project 1 phase 2\final files>kubectl apply -f ./zookeeper-setup.yaml
service/zookeeper-service created
deployment.apps/zookeeper-deployment created

C:\Users\anant\Downloads\ASU\Course work\CSE Data processing at scale\Project 1 phase 2\final files>kubectl apply -f ./kafka-setup.yaml
service/kafka-service created
deployment.apps/kafka-deployment created

---------------------------end of step 1 -------------------------------------

C:\Users\anant\Downloads\ASU\Course work\CSE Data processing at scale\Project 1 phase 2\final files>helm repo add neo4j https://helm.neo4j.com/neo4j
"neo4j" has been added to your repositories

C:\Users\anant\Downloads\ASU\Course work\CSE Data processing at scale\Project 1 phase 2\final files>helm repo update
Hang tight while we grab the latest from your chart repositories...
...Successfully got an update from the "neo4j" chart repository
Update Complete. ⎈Happy Helming!⎈

C:\Users\anant\Downloads\ASU\Course work\CSE Data processing at scale\Project 1 phase 2\final files>helm install my-neo4j-release neo4j/neo4j -f neo4j-values.yaml
NAME: my-neo4j-release
LAST DEPLOYED: Wed Nov 27 12:33:36 2024
NAMESPACE: default
STATUS: deployed
REVISION: 1
TEST SUITE: None
NOTES:
Thank you for installing neo4j.

Your release "my-neo4j-release" has been installed .

The neo4j user's password has been set to "project1phase2".To view the progress of the rollout try:

  $ kubectl rollout status --watch --timeout=600s statefulset/my-neo4j-release

Once rollout is complete you can log in to Neo4j at "neo4j://my-neo4j-release.default.svc.cluster.local:7687". Try:

  $ kubectl run --rm -it --image "neo4j:5.25.1-enterprise" cypher-shell \
     -- cypher-shell -a "neo4j://my-neo4j-release.default.svc.cluster.local:7687" -u neo4j -p "project1phase2"

Graphs are everywhere!

WARNING: Passwords set using 'neo4j.password' will be stored in plain text in the Helm release ConfigMap.
Please consider using 'neo4j.passwordFromSecret' for improved security.

C:\Users\anant\Downloads\ASU\Course work\CSE Data processing at scale\Project 1 phase 2\final files>kubectl apply -f neo4j-service.yaml
service/neo4j-service created

--------------------end of step 2 ------------------------------------------

C:\Users\anant\Downloads\ASU\Course work\CSE Data processing at scale\Project 1 phase 2\final files>kubectl apply -f kafka-neo4j-connector.yaml
service/kafka-neo4j-connector-service created
deployment.apps/kafka-neo4j-connector created



C:\Users\anant\Downloads\ASU\Course work\CSE Data processing at scale\Project 1 phase 2\final files>kubectl get pods
NAME                                     READY   STATUS    RESTARTS   AGE
kafka-deployment-c7cc98495-mmrqm         1/1     Running   0          3m50s
kafka-neo4j-connector-7b47d88ccd-tjqhw   1/1     Running   0          3m13s
my-neo4j-release-0                       1/1     Running   0          3m27s
zookeeper-deployment-7449b76cb5-bcd97    1/1     Running   0          3m56s

------------------------end of step 3 -------------------------------------


----- in 2 different terminals ------------
>kubectl port-forward svc/neo4j-service 7474:7474 7687:7687
Forwarding from 127.0.0.1:7474 -> 7474
Forwarding from [::1]:7474 -> 7474
Forwarding from 127.0.0.1:7687 -> 7687
Forwarding from [::1]:7687 -> 7687

>kubectl port-forward svc/kafka-service 9092:9092 29092:29092
Forwarding from 127.0.0.1:9092 -> 9092
Forwarding from [::1]:9092 -> 9092
Forwarding from 127.0.0.1:29092 -> 29092
Forwarding from [::1]:29092 -> 29092

---------------------------back to the original terminal ----------------------------------------------- 

C:\Users\anant\Downloads\ASU\Course work\CSE Data processing at scale\Project 1 phase 2\final files>python3 data_producer.py
{'__consumer_offsets': TopicMetadata(__consumer_offsets, 50 partitions), 'nyc_taxicab_data': TopicMetadata(nyc_taxicab_data, 1 partitions), '_connect-offsets': TopicMetadata(_connect-offsets, 25 partitions), '_connect-status': TopicMetadata(_connect-status, 5 partitions), '_connect-configs': TopicMetadata(_connect-configs, 1 partitions)}
-----------------------------
1530
1
Message sent to Kafka: b'{"trip_distance":1.2,"PULocationID":159,"DOLocationID":159,"fare_amount":7.5}'
.
.
.
Goes on until 1530 rows are complete.

1530
Message sent to Kafka: b'{"trip_distance":1.84,"PULocationID":78,"DOLocationID":242,"fare_amount":10.66}'
all done

------------------------Completes data streaming/ingesting, at this stage, the data streaming is in real time, we can see the number of nodes or edges increase as the number of data is ingested in the neo4j browser ---------
Example when it was tested while the data was still streaming- 
MATCH (n) RETURN count(n) AS total_nodes;
total_nodes
38

Once the streaming is complete, we would get 42 nodes - 
MATCH (n) RETURN count(n) AS total_nodes;

total_nodes
42

---------------------------
C:\Users\anant\Downloads\ASU\Course work\CSE Data processing at scale\Project 1 phase 2\final files>python3 tester.py
Trying to connect to server
Server is running

----------------------------------
Testing if data is loaded into the database
        Count of Edges is correct: PASS
        Count of Edges is correct: PASS
Testing if PageRank is working
        PageRank Test 1: PASS
Testing if BFS is working
        BFS Test 2: PASS
----------------------------------

Testing Complete: Note that the test cases are not exhaustive. You should run your own tests to ensure that your code is working correctly.

------------------------------ Thus completes step 4 --------------------------------------------



